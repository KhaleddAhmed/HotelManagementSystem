class AllServicesModel {
  int? statusCode;
  String? message;
  List<Data>? data;

  AllServicesModel({this.statusCode, this.message, this.data});

  AllServicesModel.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    message = json['message'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['statusCode'] = this.statusCode;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  int? serviceType;
  int? serviceFees;

  Data({this.id, this.serviceType, this.serviceFees});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    serviceType = json['serviceType'];
    serviceFees = json['serviceFees'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['serviceType'] = this.serviceType;
    data['serviceFees'] = this.serviceFees;
    return data;
  }
}
